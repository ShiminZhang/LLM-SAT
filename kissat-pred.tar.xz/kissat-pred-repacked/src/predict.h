#ifndef _predict_h_INCLUDED
#define _predict_h_INCLUDED

struct kissat;

void kissat_predict (struct kissat *);

#endif
